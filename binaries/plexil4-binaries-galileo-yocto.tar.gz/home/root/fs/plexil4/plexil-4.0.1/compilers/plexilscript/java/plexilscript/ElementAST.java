
//
// ElementAST
//

package plexilscript;

interface ElementAST {
    public void print ();
}

